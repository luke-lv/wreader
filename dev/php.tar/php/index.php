<?php
//include ('__global.php');

header('Location:/guang');
?>