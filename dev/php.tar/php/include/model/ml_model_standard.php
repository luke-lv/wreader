<?php
/**
 * 
 */
class ml_model_standard extends Lib_datamodel_db 
{
    private $dataDefine
    function __construct($dataDefine)
    {
        $this->dataDefine = $dataDefine;
        $db_config = ml_factory::load_standard_conf('dbContentbase');        //目前只有一个配置文件，所以

        parent::__construct('wr_contentbase' , $db_config['wr_contentbase']);
        $this->table = 'wrc_source';
    }
    
    function std_listByPage($page = 1 , $pagesize = 10)
    {
        $start = ($page-1)*$pagesize;
        $sql = 'select * from '.$this->table.' where order by id desc limit '.$start.','.$pagesize;
        return $this->fetch($sql);
    }

    function std_getCount()
    {
        return $this->fetch_count();
    }

    function std_getRowById($id)
    {
        $sql = 'select * from '.$this->table.' where id='.$id;
        return $this->fetch_row($sql);
    }

    function std_addRow($data = array())
    {
        return $this->insert($data);
    }
}
?>