<?php
/**
 *@fileoverview: [群博客] 
 *@author: 辛少普 <shaopu@staff.sina.com.cn>
 *@date: Wed Apr 27 09:12:09 GMT 2011
 *@copyright: sina
 */

return array(
    'meila_cnt' => array(
        array('host'=>'127.0.0.1' , 'port'=>'6381'),
    ),
    'meila_cache' => array(
        array('host'=>'127.0.0.1' , 'port'=>'6383'),
    ),
    'meila_queue' => array(
        array('host'=>'127.0.0.1' , 'port'=>'6380'),
    ),
    'meila_guang' => array(
        array('host'=>'127.0.0.1' , 'port'=>'6382'),
    ),
);
?>