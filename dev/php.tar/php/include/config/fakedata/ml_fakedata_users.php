<?php

return array(
    'tag_biguser' => array(
        '牛仔' => array(),
    ),
    'class_biguser' => array(
        ML_CATELOG_CLOTHES => array(),
    ),
    'smalluser' => array(),
);