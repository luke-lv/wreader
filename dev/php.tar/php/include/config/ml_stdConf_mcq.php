<?php
/**
 *@fileoverview: [群博客] 
 *@author: 辛少普 <shaopu@staff.sina.com.cn>
 *@date: Wed Apr 27 09:12:09 GMT 2011
 *@copyright: sina
 */

return array(
    'default' => array(
          array('host'=>'127.0.0.1' , 'port'=>'22201'),    //这两个是一样的，为了兼容老的队列系统
          array('host'=>'127.0.0.1' , 'port'=>'22201'),    //这两个是一样的，为了兼容老的队列系统
    ),
);
?>