<?php

define('ML_ADMQUEUENAME_ADDFAKEDATA' , 'mla_addfake');