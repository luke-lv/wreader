<?php
return array(
    'admin' => array(
        'pw' => '909f557ce041a585b88bac223d8af0e5',
        'level' => 1,
    ),
    'datamanager' => array(
        'pw' => '36f17c3939ac3e7b2fc9396fa8e953ea',
        'level' => 2,
    ),
);