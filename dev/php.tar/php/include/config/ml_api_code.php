<?php
/**
 *@fileoverview: [群博客] 
 *@author: 辛少普 <shaopu@staff.sina.com.cn>
 *@date: Tue Nov 30 06:47:05 GMT 2010
 *@copyright: sina
 */

define('ML_RCODE_BUSY' , 'A00001');
define('ML_RCODE_IP' , 'A00002');
define('ML_RCODE_PARAM' , 'A00003');
define('ML_RCODE_NOLOGIN' , 'A00004');
define('ML_RCODE_HACK' , 'A00005');
define('ML_RCODE_SUCC' , 'A00006');
define('ML_RCODE_FAIL' , 'A00007');
define('ML_RCODE_NOACTIVE' , 'A00008');

define('ML_RMESSAGE_BUSY' , '系统繁忙，请稍候重试啊，亲~~~');
?>