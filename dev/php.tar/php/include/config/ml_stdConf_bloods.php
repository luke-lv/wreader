<?php
return array(1=>'A',2=>'B',3=>'AB',4=>'O',9=>'其他');
?>