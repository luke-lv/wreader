<?php
return array(
    'meila' , 
    '美啦' , 
    'sina' , 
    '新浪' , 
);