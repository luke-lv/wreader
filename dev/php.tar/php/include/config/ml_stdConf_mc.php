<?php
/**
 *@fileoverview: [群博客] 
 *@author: 辛少普 <shaopu@staff.sina.com.cn>
 *@date: Wed Apr 27 09:12:09 GMT 2011
 *@copyright: sina
 */

return array(
    'group_info' => array(
        array('host'=>'10.55.37.212' , 'port'=>'8821'),
    ),
    'meila_guang' => array(
        array('host'=>'127.0.0.1' , 'port'=>'11211'),
        array('host'=>'127.0.0.1' , 'port'=>'11211'),
        array('host'=>'127.0.0.1' , 'port'=>'11211'),
        array('host'=>'127.0.0.1' , 'port'=>'11211'),
    ),
    'lb_filter' => array(
        array('host'=>'127.0.0.1', 'port'=>'11211'),
        array('host'=>'127.0.0.1', 'port'=>'11211'),
        array('host'=>'127.0.0.1', 'port'=>'11211'),
    ),
    'tinyurl' => array(
        array('host'=>'172.16.115.23', 'port'=>'22206'),
        array('host'=>'172.16.115.23', 'port'=>'22206'),
        array('host'=>'172.16.115.23', 'port'=>'22206'),
        array('host'=>'172.16.115.23', 'port'=>'22206'),
    ),
    'weiboshare' => array(
        array('host'=>'pvdb21204.vader.matrix.sina.com.cn', 'port'=>'21204'),
        array('host'=>'pvdb21204.vader.matrix.sina.com.cn', 'port'=>'21204'),
        array('host'=>'pvdb21204.vader.matrix.sina.com.cn', 'port'=>'21204'),
        array('host'=>'pvdb21204.vader.matrix.sina.com.cn', 'port'=>'21204'),
    ),
);
?>