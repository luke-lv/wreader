<?php
define('TRD_TYPE_ID_SINA', 1);
define('TRD_TYPE_ID_TENCENT', 2);
define('TRD_TYPE_ID_RENREN', 3);
define('TRD_TYPE_ID_KAIXIN', 4);
define('TRD_TYPE_ID_TAOBAO', 5);