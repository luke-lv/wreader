<?php

return array(
        'big' => array(
                'type' => ML_IMG_TYPE_REGULARWIDTH,
                'width' => 200,
                'def_path' => ''
            ),
        'mid' => array(
                'type' => ML_IMG_TYPE_REGULARWIDTH,
                'width' => 120,
                'def_path' => ''
            ),
        'sml' => array(
                'type' => ML_IMG_TYPE_REGULARWIDTH,
                'width' => 50,
                'def_path' => ''
            ),
        'tny' => array(
                'type' => ML_IMG_TYPE_REGULARWIDTH,
                'width' => 30,
                'def_path' => ''
            ),
        'atm' => array(
                'type' => ML_IMG_TYPE_REGULARWIDTH,
                'width' => 18,
                'def_path' => ''
            ),
);