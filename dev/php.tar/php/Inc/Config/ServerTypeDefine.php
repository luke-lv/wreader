<?php


//服务器类型 front queue lmdemo dev
define('SYSDEF_SERVER_TYPE' , 'front');