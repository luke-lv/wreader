<?php 
	function addForm($data)
	{
		$dataDefine=ml_factory::load_dataDefine($data['dataDefine']);
?>
		<table width="98%" border="0" align="center" cellspacing="0" class="adminlist">
			<th>
				<td colspan="2">新增</td>
			</th>
			<?php foreach ($dataDefine as $name => $value) { ?>
			<tr>
				<td><?php echo $value['cn'] ?></td>
				<td><?php echo ml_tool_admin_view::dtdfn_input($value['type'] , $name , $value); ?></td>
			</tr>
			<?php } ?>
			<tr>
				<td colspan="2"><input type="submit" value="保存"/></td>
			</tr>
		</table>
<?php
	}

	function editFrom()
	{
		$dataDefine=ml_factory::load_dataDefine($data['dataDefine']);
?>
		<table width="98%" border="0" align="center" cellspacing="0" class="adminlist">
			<th>
				<td colspan="2">编辑</td>
			</th>
			<tr>
				<?php foreach ($dataDefine as $name => $value) { ?>
				<tr>
					<td><?php echo $value['cn'] ?></td>
					<td><?php echo ml_tool_admin_view::dtdfn_input($value['type'] , $name , $value); ?></td>
				</tr>
				<?php } ?>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" value="保存"/></td>
			</tr>
		</table>
<?php
	}

	function list($data)
	{
		$rows = $data['list'];
?>
		<table width="98%" border="0" align="center" cellspacing="0" class="adminlist">
			<th>
				<td>#</td>
				<td>标题</td>
				<td>rss</td>
				<td>域名</td>
			</th>
			<?php foreach ($rows as $key => $value) { ?>
			<tr>
				<td><?php mla_echo($value['id']) ?></td>
				<td><?php mla_echo($value['title']) ?></td>
				<td><?php mla_echo($value['rss']) ?></td>
				<td><?php mla_echo($value['domain']) ?></td>
			</tr>
			<?php } ?>
			<tr>
				<td colspan="2"><?php echo ml_tool_admin_view::get_page($data['total'] , $data['pagesize'] , $data['page']); ?></td>
			</tr>
		</table>
<?php
	}
?>
