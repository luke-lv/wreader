<?php

include('../__global.php');


class adm_standard extends admin_ctrl
{
    private $dataDefine;
    private $model

    public function _construct()
    {
        
        $this->dataDefine = $this->input('dtdfn');
        $this->model = new ml_model_standard($this->dataDefine);

        //
    }
    
    protected function output($data)
    {
        $data['_dataDefine'] = $this->dataDefine;
        parent::output($data);
    }

    protected function page_addForm()
    {
        $this->output();
    }
    protected function page_editForm()
    {
        $id = $this->input('id');
        $this->model->std_getRowById($id);
        $data['row'] => $this->model->get_data();
        $this->output($data);
    }
    
    
}

new adm_standard();
?>
