<?php

include('../__global.php');

class adm_member_apply extends admin_ctrl
{    
    
}

new adm_member_apply();
?>